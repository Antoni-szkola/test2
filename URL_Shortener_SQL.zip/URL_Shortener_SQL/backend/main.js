// Setup environment variables
import 'dotenv/config' 

import path from 'path';
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));

import pg from "pg"
const { Client } = pg
const client = new Client({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    port: Number(process.env.DB_PORT),
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
})

// Connect to the PostgreSQL database
client.connect()
  .then(() => {
    console.log('Connected to PostgreSQL database');
  })
  .catch(err => {
    console.error('Connection error', err.stack);
  });



  (async () => {
    try {
        await client.query(`
            CREATE TABLE IF NOT EXISTS links (
                id SERIAL PRIMARY KEY,
                url TEXT NOT NULL
            )
        `);
        console.log('Table ensured.');
    } catch (err) {
        console.error('Error creating table:', err);
    }
})();

// Import and setup Express
import express from "express"
import bodyParser from "body-parser"
import cors from "cors"
const app = express()
app.use(bodyParser.urlencoded({extended: false}))
app.use(cors({
    methods: ["GET", "POST", "OPTIONS"]
}))

// If URL exists, it returns its ID, otherwise it retuns null
async function URLAlreadyExists(url) {
    try {
        const res = await client.query(`SELECT id FROM links WHERE url = $1`, [url]);

        if (res.rowCount !== 0) {
            return res.rows[0].id // Return id if URL already exists in db
        }
    } catch (err) {
        console.error(err);
    }
    return null;
}

// Returns ID of inserted URL
async function InsertURL(url) {
    try {
        const res = await client.query(`INSERT INTO links (url) VALUES ($1) RETURNING id`, [url]);
        return res.rows[0].id;
    } catch (err) {
        console.error(err);
        return null;
    }
}

app.post("/update", async(req, res) => {
    const url = req.body["url"];
    
    try {
        const exists = await URLAlreadyExists(url);

        if (exists == null) { // Create and send new ID
            const new_id = await InsertURL(url);

            if (new_id == null) {
                res.sendStatus(500); // Send error if something has gone wrong
            } else {
                res.status(200).send(String(new_id));
            }
        } else { // Send ID if it already exists
            res.status(200).send(String(exists)) 
        }
    } catch (err) {
        console.error(err);
        res.sendStatus(500);
    }
})

app.get("/:id", async (req, res) => {
    const id = req.params.id;
    const idNumber = parseInt(id);

    if (isNaN(idNumber || idNumber <= 0)) {
        return res.status(400).send("Invalid ID");
    }

    try {
        const result = await client.query("SELECT url FROM links WHERE id = $1", [id]);
        
        if (result.rowCount === 0) {
            return res.status("404").send("Link not found");
        }

        res.status(200).send(`<html><script>window.location.replace("${result.rows[0].url}")</script></html>`);
    } catch (err) {
        console.error(err);
        res.sendStatus(500);
    }
})

app.use(express.static("dist"))
app.get("/", (req, res) => {
    try {
        res.status(200).sendFile(path.join(__dirname, "/dist/index.html"));
    } catch(e) {
        console.error(e);
        res.sendStatus(500);
    }
})

try {
    app.listen(Number(process.env.EXPRESS_PORT), () => {
        console.log("Server running on port", process.env.EXPRESS_PORT)
    })
} finally {
    // await client.end();
}