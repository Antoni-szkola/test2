// Setup environment variables
import 'dotenv/config' 

import path from 'path';
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Import MongoDB API
import { MongoClient, ServerApiVersion } from 'mongodb';

// Import and setup Express
import express from "express"
import bodyParser from "body-parser"
import cors from "cors"
const app = express()
app.use(bodyParser.urlencoded({extended: false}))
app.use(cors())

// Import crypto library to later generate unique IDs
import crypto from "crypto"

// Connect to Database
const client = new MongoClient(process.env.URI, {
    serverApi: {
      version: ServerApiVersion.v1,
      strict: true,
      deprecationErrors: true,
    }
});
try {
    await client.connect();
    await client.db("admin").command({ ping: 1 });
} catch(e) {
    console.error(e)
}
const db = client.db("URL_Shortcuter")
console.log("Successfully connected to MongoDB");


function ValueAlreadyExists(docs, value) {
    for (const doc of docs) {
        for (const [key, v] of Object.entries(doc)) {
            if (v == value) {
                return key
            }
        }
    }
    return null;
}
function KeyAlreadyExists(docs, value) {
    for (const doc of docs) {
        for (const [key, v] of Object.entries(doc)) {
            if (key == value) {
                return true;
            }
        }
    }
    return false;
}

// Generate random 5-element ID
const GenerateRandomId = () => crypto.randomBytes(5).toString("hex").slice(0, 5)

app.post("/update", async(req, res) => {
    const url = req.body["url"];
    const collection = db.collection("URLs");
    const docs = await collection.find({}).toArray();
    
    // Get random ID
    let new_id = GenerateRandomId()

    // Check if id already exists, if so, generate new one until it is unique
    while (KeyAlreadyExists(docs, new_id)) {
        new_id = GenerateRandomId()
    }

    // Check if URL already exists in database, if so send its id, else insert new one into database
    const currDate = new Date().toJSON().split("T")[0];
    const exists = ValueAlreadyExists(docs, url)
    if (exists) {
        res.status(201).send(exists)
    } else {
        await collection.updateOne({"CreatedAt": currDate}, {"$set": {[new_id]: url}}, { upsert: true})
        res.status(201).send(new_id)
        
    } 
})

app.get("/:id", async(req, res) => {
    // Get key from URL of website
    const key = req.params.id

    // Check if key's length is right
    if (key.length != 5) {
        res.sendStatus(404);
        return;
    }

    // Retrieve collection
    const collection = db.collection("URLs");
    
    // If ID doesn't exist, send error, else send redirecting HTML
    const query = {}; query[key] = {$exists: true};
    const result = await collection.find(query).toArray();
    if (result.length == 0) {
        res.sendStatus(404);
    } else {
        res.status(200).send(`<html><script>window.location.replace("${result[0][key]}")</script></html>`);
    }
})

app.use(express.static("dist"))
app.get("/", (req, res) => {
    try {
        res.status(200).sendFile(path.join(__dirname, "/dist/index.html"));
    } catch(e) {
        console.error(e);
        res.sendStatus(500);
    }
})

try {
    app.listen(Number(process.env.EXPRESS_PORT), () => {
        console.log("Server running on port", process.env.EXPRESS_PORT)
    })
} finally {
    //await client.close();
}