<script lang="ts">
    import { responseData } from './store';

    const GetIconFromDomain = (link: string) => `https://www.google.com/s2/favicons?domain=${new URL(link).hostname}`;
    //const CreateLink = (id: string) => `${window.location.hostname}/${id}`;
    const CreateLink = (id: string) => `http://${window.location.hostname}/${id}`;

</script>

{#if $responseData != null}
{@const NewURL=CreateLink($responseData.id)}
    <div id="result">
        <a target="_blank" rel="noopener" id="shortened_url" href={NewURL}><p>{NewURL}</p></a>
        <div id="original_url">
            <img src={GetIconFromDomain($responseData.url)} width="20" alt="icon">
            <span>{$responseData.url}</span>
        </div>
        <button on:click={() => navigator.clipboard.writeText(NewURL)} id="copy_btn">Copy Link</button>
    </div>
{/if}

<style lang="scss">
    #result {
        position: relative;
        background-color: hsl(189, 52%, 75%);
        padding: 2px;
        margin-top: 5px;

        border-radius: 0.5em;
    }
    
    #copy_btn {
        position: absolute;
        right: 0;
        top: 50%;
        transform: translate(0, -50%);

        margin-right: 10px;
        text-align: center;
        width: max-content;
        height: auto;
        font-size: 1.2em;
        padding: 5px;
        border: 1px solid transparent;
        background-color: hsl(182, 25%, 21%);
        border-radius: 5px;
        color: #fff;
        transition: 0.5s;

        &:hover {
            cursor: pointer;
            background-color: hsl(180, 18%, 14%);
        }
    }

    #shortened_url p {
        margin-left: 5px;
    }

    #original_url {
        position: relative;
        height: fit-content;

        img {
            margin-left: 5px;
        }

        span {
            color: #0c5460;

            font-size: 1rem;
            margin-left: 0.3em;
            position: absolute;
            top: 50%;
            transform: translate(0, -60%);

            width: 75%;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
    }
</style>