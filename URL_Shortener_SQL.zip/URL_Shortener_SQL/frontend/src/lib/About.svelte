<script>

</script>

<div id="about">
    <h1>Shorten URLs</h1>
    <p>URL Shortener makes long links look cleaner and easier to share! Easily create short links you can share with your friends.</p>
</div>

<style lang="scss">
    #about {
        position: absolute;
        top: 200px;
        left: 50%;
        transform: translate(-50%, 0);

        h1, p {
            text-align: center;
        }

        p {
            font-size: 20px;
        }

        
    }
</style>