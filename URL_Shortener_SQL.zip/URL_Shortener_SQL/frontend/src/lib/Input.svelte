<script lang="ts">
    import axios from "axios";
    import { responseData } from "./store";

    let input = "";

    async function POST() {
        // Check if input is string
        if (input === "") return;

        // Add http prefix if needed
        input = (input.indexOf('://') === -1) ? 'http://' + input : input;

        // Check if input is correct URL
        try {
            new URL(input)
        } catch(e) {
            console.error(e)
            return
        }

        try {
            const response = await axios.post(
                `${window.location.protocol}//${window.location.hostname}/update`,
                {
                    url: input,
                },
                {
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                },
            );
            if (response.status === 200) {
                responseData.set({
                    "id": response.data,
                    "url": input
                });
            } else {
                responseData.set(null);
            }
        } catch (e) {
           responseData.set(null);
        }
    }
</script>

<div id="wrapper" class="proper_width">
    <input bind:value={input} type="url"  placeholder="Enter URL..." id="in" />
    <button on:click={POST} id="add"></button>
</div>

<style lang="scss">
    #wrapper {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 750px;
    }

    #in {
        flex: 1;
        height: 50px;
        font-size: 1.25rem;
        margin-right: 0;
        width: auto;
        border: 2px solid transparent;
        color: rgb(60, 62, 65);
        
        border: 2px solid #789596;
        border-radius: 0.3em 0px 0px 0.3em;
        border-right: 0px solid transparent;
        
        transition: 0.25s;

        &:hover {
            outline: 0;
        
            border: 2px solid #40595a;
            border-right: 0px solid transparent;
        }
    }


    #add {
        margin: 0;
        width: max-content;
        height: 55px;
        font-size: 1.25rem;
        padding: 5px;
        border: 2px solid transparent;
        background-color: #284243;
        border-radius: 0px 0.3em 0.3em 0px;
        border-left: 0px solid transparent;
        color: #fff;
        transition: 0.5s;

        &:hover {
            cursor: pointer;
            background-color: #1e2b2b;
        }

        &::after {
            content: "Shorten URL";
        }
    }

    @media only screen and (max-width: 1050px) {
        #wrapper {
            width: 75vw;
        }
    }

    @media only screen and (max-width: 775px) {
        #wrapper {
            width: 85vw;
        }

        #add {
            width: 15%;

            &::after {
                content: ">";
            }
        }
    }

    @media only screen and (max-width: 550px) {
        #in {
            width: 75%;
        }
    }
</style>
