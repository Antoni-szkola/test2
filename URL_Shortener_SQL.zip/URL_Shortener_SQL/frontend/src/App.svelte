<script lang="ts">
  import Input from './lib/Input.svelte';  
  import Result from './lib/Result.svelte';
  import About from './lib/About.svelte';

</script>

<h1 id="title">Create Short URLs</h1>

<main>

  <Input />
  <Result />

  <About />
</main>


<style>
  main {
    position: absolute;
    left: 50%;
    transform: translate(-50%, 0);
    top: 25%;
  }

  #title {
    text-align: center;
    font-size: 60px;
    color: #284243;
  }
</style>
